# GitHub 上传教程（网页操作）

准备文件：`Fables-LP-GitHub-v1.0.0.zip`。这是一个完整源码与文档包；不用把当前工作目录或已经运行过的工具文件夹重新压缩。

## 方法一：只上传一个 ZIP

1. 登录自己的 GitHub 账号，打开 [创建仓库](https://github.com/new)。
2. 仓库名称可填 `fables-lp-lab`，描述可填“本机运行的 Fables LP 配比、收益与无常损失测算工具”。
3. 可见性建议先选 **Private**；以后决定分享时再调整。勾选添加 README，创建仓库。不要填入钱包、电脑路径或其他个人资料。
4. 进入仓库 **Code** 页，点击 **Add file → Upload files**。
5. 把 `Fables-LP-GitHub-v1.0.0.zip` 拖入上传框，等待上传完成。
6. 提交说明填 `Add Fables LP local tool v1.0.0`，点击 **Commit changes**。
7. 点击仓库里的 ZIP 文件，使用下载原始文件的按钮取回，完整解压后检查能否启动。

这样仓库保存的是一个可下载压缩包；GitHub 不会自动将它解压为源码文件。

官方说明：[创建仓库](https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository)、[网页上传文件](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)。

## 方法二：让仓库直接展示源码和说明

如果希望在 GitHub 页面直接看到使用说明、修改记录和代码：

1. 将发布 ZIP 解压到一个新的空目录，打开其中的 `fables-lp-lab` 文件夹。
2. 在仓库中使用 **Add file → Upload files**，上传这个文件夹内的发布文件，确保 `README.md` 位于仓库根目录。
3. 不要使用已经运行并生成缓存的目录。文件管理器可能隐藏 `.gitignore`，请确认它也已上传。
4. 查看即将提交的文件清单，应与包内 `MANIFEST.sha256` 的条目一致，另加清单文件本身；确认没有 `data/`、日志或 CSV。
5. 提交后，仓库首页会展示 README。

这与上传单个 ZIP 是两种方式，可按需要选一种。已有仓库 README 时，先比较内容再决定是否替换。

## 可选：把 ZIP 挂到版本发布页

仓库有初始提交后，打开 **Releases → Draft a new release / Create a new release**。新建标签 `v1.0.0`，标题填 `Fables LP 实验室 v1.0.0`，将 ZIP 拖到附件区域，然后发布。用户即可从该版本的附件下载。

发布说明可使用：“本机运行的 LP 规划工具，包含池子数据、区间配比、九个时段收益、无常损失和方案导出。需 Python 3.9+。不连接钱包、不发送交易。详见包内 README 与使用说明。”

官方说明：[管理 Releases 与添加附件](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)。

## 账号和隐私

- 不要把 GitHub 密码、访问令牌、私钥或助记词放入文件或提交说明。
- 即使仓库是私有，也仅上传此干净发布包。
- 发布包无法隐藏 GitHub 平台自身显示的账号、提交者等信息；这些由你的 GitHub 账号与仓库设置决定。
- 网页上传前核对账号与仓库，避免上传到错误的组织。
- GitHub 不会替你运行本机 Python 服务；上传文件不等于部署网站。

本教程仅指导操作；提供发布包本身不代表已经上传到 GitHub。
